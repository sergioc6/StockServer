<div class="footer">
    <div class="row">
        <div class="col-lg-12" >
            &copy;  2016 Sistema de Control de Stock | Design by: Cabral Sergio y Leiva Nahuel
        </div>
    </div>
</div>